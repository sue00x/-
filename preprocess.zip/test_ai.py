# test_llm_direct.py
from llm_client import LLMClient
import json

print("🔥 Testing LLM connection...")

try:
    with open("config.json") as f:
        cfg = json.load(f)
    
    llm = LLMClient(cfg["API_URL"], cfg["API_KEY"], cfg["MODEL"])
    
    result = llm.chat([
        {"role": "system", "content": "请用中文回答"},
        {"role": "user", "content": "你好，请说'测试成功'"}
    ], temperature=0.0)
    
    print(f"✅ LLM SUCCESS: {result}")
    
except Exception as e:
    print(f"❌ LLM FAILED: {e}")
    import traceback
    traceback.print_exc()