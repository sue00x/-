# candidates 解析结果

## b5eb72a560b8149a1885

```
BUG: KASAN: slab-use-after-free in do_check+0xb388/0xe170

Read of size 1 at addr ffff88801deeef79 by task syz-executor672/5842

CPU: 1 UID: 0 PID: 5842 Comm: syz-executor672 Not tainted 6.16.0-rc1-next-20250611-syzkaller #0 PREEMPT(full)

Hardware name: Google Google Compute Engine/Google Compute Engine, BIOS Google 05/07/2025

Call Trace:
<TASK>
dump_stack_lvl+0x99/0x250

Allocated by task 5842:
kasan_save_track+0x3e/0x80
__kasan_kmalloc+0x93/0xb0
__kmalloc_cache_noprof+0x230/0x3d0
do_check_common+0x13f/0x20b0
bpf_check+0x1381e/0x19e50
bpf_prog_load+0x1318/0x1930
do_initcalls+0x69/0xd0
kernel_init_freeable+0x3d9/0x570
kernel_init+0x1d/0x1d0

Freed by task 5842:
kasan_save_free_info+0x46/0x50
__kasan_slab_free+0x62/0x70
kfree+0x18e/0x440
push_stack+0x247/0x3c0
check_cond_jmp_op+0x1069/0x2340
do_check+0x672c/0xe170
do_check_common+0x168d/0x20b0

The buggy address belongs to the object at ffff88801deeef00
which belongs to the cache kmalloc-192 of size 192
The buggy address is located 121 bytes inside of
freed 192-byte region [ffff88801deeef00, ffff88801deeefc0)
The buggy address belongs to the physical page:

Memory state around the buggy address:
ffff88801deeee00: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
ffff88801deeee80: 00 00 00 00 00 00 00 fc fc fc fc fc fc fc fc fc
>ffff88801deeef00: fa fb fb fb fb fb fb fb fb fb fb fb fb fb fb fb
ffff88801deeef80: fb fb fb fb fb fb fb fb fc fc fc fc fc fc fc fc
ffff88801deef000: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
==================================================================

page last free pid 1 tgid 1 stack trace:
__free_frozen_pages+0xc71/0xe70
kasan_populate_vmalloc+0x18a/0x1a0
alloc_vmap_area+0xd51/0x1490
__get_vm_area_node+0x1f8/0x300
__vmalloc_node_range_noprof+0x301/0x12f0
vmalloc_huge_node_noprof+0xb3/0xf0
alloc_large_system_hash+0x2b8/0x5e0
posixtimer_init+0x140/0x270
do_one_initcall+0x233/0x820
do_initcall_level+0x137/0x1f0
ret_from_fork+0x3f9/0x770
ret_from_fork_asm+0x1a/0x30
page: refcount:0 mapcount:0 mapping:0000000000000000 index:0x0 pfn:0x1deee
flags: 0xfff00000000000(node=0|zone=1|lastcpupid=0x7ff)
page_type: f5(slab)
raw: 00fff00000000000 ffff88801a4413c0 ffffea00006fca40 dead000000000004
raw: 0000000000000000 0000000000100010 00000000f5000000 0000000000000000
page dumped because: kasan: bad access detected
page_owner tracks the page as allocated
page last allocated via order 0, migratetype Unmovable, gfp_mask 0x52820(GFP_ATOMIC|__GFP_NOWARN|__GFP_NORETRY|__GFP_COMP), pid 1, tgid 1 (swapper/0), ts 2954361175, free_ts 2954343552
post_alloc_hook+0x240/0x2a0
get_page_from_freelist+0x21e4/0x22c0
__alloc_frozen_pages_noprof+0x181/0x370
alloc_pages_mpol+0x232/0x4a0
allocate_slab+0x8a/0x3b0
___slab_alloc+0xbfc/0x1480
__kmalloc_node_noprof+0x2fd/0x4e0
__vmalloc_node_range_noprof+0x5a9/0x12f0
^

RIP: 0033:0x7f7586cdbeb9
Code: 28 00 00 00 75 05 48 83 c4 28 c3 e8 c1 17 00 00 90 48 89 f8 48 89 f7 48 89 d6 48 89 ca 4d 89 c2 4d 89 c8 4c 8b 4c 24 08 0f 05 <48> 3d 01 f0 ff ff 73 01 c3 48 c7 c1 b8 ff ff ff f7 d8 64 89 01 48

RSP: 002b:00007ffc2e683128 EFLAGS: 00000246 ORIG_RAX: 0000000000000141
RAX: ffffffffffffffda RBX: 0000000000000000 RCX: 00007f7586cdbeb9
RDX: 0000000000000094 RSI: 0000200000000840 RDI: 0000000000000005
RBP: 0000000000000000 R08: 0000000000000000 R09: 0000000000000006
R10: 0000000000000000 R11: 0000000000000246 R12: 0000000000000000
R13: 0000000000000000 R14: 0000000000000001 R15: 0000000000000001

Rebooting in 86400 seconds..

</TASK>
Kernel panic - not syncing: KASAN: panic_on_warn set ...
Kernel Offset: disabled
```

